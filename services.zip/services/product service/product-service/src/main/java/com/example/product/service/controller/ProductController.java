package com.example.product.service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.product.service.model.Product;
import com.example.product.service.service.ProductService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("api/products")
public class ProductController {
    
    @Autowired
    ProductService productService;

    @PostMapping
    public Product create(@Valid @RequestBody Product product){
        return productService.save(product);
    }

    @GetMapping
    public List<Product> getAll(){
        return productService.getAll();
    }

    @GetMapping("/{id}")
    public Product getProductById(@Valid Long id){
        return productService.getProductById(id);
    }

    @PutMapping("/{id}")
    public Product updateProduct(@Valid @PathVariable Long id,@Valid @RequestBody Product updatedProduct){
        return productService.updateProduct(id, updatedProduct);
    }

    @DeleteMapping("/{id}")
    public String deleteProduct(@Valid @PathVariable Long id){
        productService.deleteProduct(id);
        return "Product deleted successfully with id: " + id;
    }

    @GetMapping("/search")
    public List<Product> searchProducts( @Valid @RequestParam String name) {
        return productService.searchProducts(name);
    }

    @GetMapping("/filter")
     public List<Product> filterByPrice(@Valid @RequestParam double minPrice,@Valid @RequestParam double maxPrice) {
        return productService.filterByPrice(minPrice, maxPrice);
    }

    @GetMapping("/paginated")
    public Page<Product> getProducts(@Valid @RequestParam int page,@Valid @RequestParam int size) {
        return productService.getProducts(page, size);
    }
}

