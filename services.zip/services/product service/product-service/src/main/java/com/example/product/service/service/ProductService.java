package com.example.product.service.service;

import java.util.List;
import org.springframework.data.domain.Page;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.example.product.service.Repository.ProductRepository;
import com.example.product.service.model.Product;

@Service
public class ProductService {
    
    @Autowired
    private ProductRepository productRepository;

    public Product save(Product p){
        return productRepository.save(p);
    }

    public List<Product> getAll(){
        return productRepository.findAll();
    }

    public Product getProductById(Long id){
        return productRepository.findById(id).orElseThrow(()-> new RuntimeException("Product not found with id:  "+id));
    }

    public Product updateProduct(Long id, Product updatedProduct){
        Product existingProduct = productRepository.findById(id).
        orElseThrow(()-> new RuntimeException("Product not found with id: \" + id)"));

        existingProduct.setName(updatedProduct.getName());
        existingProduct.setDescription(updatedProduct.getDescription());
        existingProduct.setPrice(updatedProduct.getPrice());

        return productRepository.save(existingProduct);

    }

    public void deleteProduct(Long id){
        Product existingProduct = productRepository.findById(id).orElseThrow(() -> new RuntimeException("Product not found with id: " + id));
        productRepository.delete(existingProduct);
    }

    public List<Product> searchProducts(String name) {
         return productRepository.findByNameContainingIgnoreCase(name);
    }

    public List<Product> filterByPrice(double minPrice, double maxPrice) {
        return productRepository.findByPriceRange(minPrice, maxPrice);
    }

    public Page<Product> getProducts(int page, int size) {
    Pageable pageable = PageRequest.of(page, size);
    return productRepository.findAll(pageable);
}
}


