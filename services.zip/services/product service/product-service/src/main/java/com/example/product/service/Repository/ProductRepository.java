package com.example.product.service.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.product.service.model.Product;

public interface ProductRepository extends JpaRepository<Product, Long>
{
    List<Product> findByNameContainingIgnoreCase(String name);

    /*We are writing custom JPQL query:

BETWEEN → range filtering
:minPrice, :maxPrice → parameters */
    @Query("SELECT p FROM Product p WHERE p.price BETWEEN :minPrice AND :maxPrice")
List<Product> findByPriceRange(@Param("minPrice") double minPrice,
                               @Param("maxPrice") double maxPrice);
}