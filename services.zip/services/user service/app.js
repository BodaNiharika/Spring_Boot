import { useState } from "react";

function App() {

  const [regUser, setRegUser] = useState("");
  const [regPass, setRegPass] = useState("");

  const [logUser, setLogUser] = useState("");
  const [logPass, setLogPass] = useState("");

  const [message, setMessage] = useState("");

  const REGISTER_URL = "http://localhost:8084/api/auth/register";
  const LOGIN_URL = "http://localhost:8084/api/auth/login";

  /* ---------------- REGISTER ---------------- */
  const register = async () => {

    const user = {
      username: regUser,
      password: regPass
    };

    const response = await fetch(REGISTER_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(user)
    });

    const data = await response.text();
    setMessage("Register: " + data);
  };

  /* ---------------- LOGIN ---------------- */
  const login = async () => {

    const user = {
      username: logUser,
      password: logPass
    };

    try {
      const response = await fetch(LOGIN_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(user)
      });

      const data = await response.text();
      setMessage("Login: " + data);

    } catch (error) {
      setMessage("Login failed (server error)");
    }
  };

  return (
    <div>

      <h2>Register</h2>

      <input
        placeholder="Username"
        value={regUser}
        onChange={(e) => setRegUser(e.target.value)}
      />
      <br /><br />

      <input
        type="password"
        placeholder="Password"
        value={regPass}
        onChange={(e) => setRegPass(e.target.value)}
      />
      <br /><br />

      <button onClick={register}>Register</button>

      <hr />

      <h2>Login</h2>

      <input
        placeholder="Username"
        value={logUser}
        onChange={(e) => setLogUser(e.target.value)}
      />
      <br /><br />

      <input
        type="password"
        placeholder="Password"
        value={logPass}
        onChange={(e) => setLogPass(e.target.value)}
      />
      <br /><br />

      <button onClick={login}>Login</button>

      <p>{message}</p>

    </div>
  );
}

export default App;