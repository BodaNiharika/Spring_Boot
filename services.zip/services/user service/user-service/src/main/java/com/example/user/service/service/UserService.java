package com.example.user.service.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.user.service.Repository.UserRepository;
import com.example.user.service.dto.UserRequest;
import com.example.user.service.dto.UserResponse;
import com.example.user.service.model.User;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public UserResponse register(UserRequest request){
        // Repository always works with Entity, not DTO
        User existing = userRepository.findByUsername(request.getUsername());

        if (existing != null) {
            throw new RuntimeException("User already exists");
        }

        // manually mapping from dto to entity
        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(request.getPassword());

        User savedUser = userRepository.save(user);

        return UserResponse.builder()
                .id(savedUser.getId())
                .username(savedUser.getUsername())
                .build();
    }

    public String login(UserRequest request){
        User user = userRepository.findByUsername(request.getUsername());

        if (user == null) {
            throw new RuntimeException("User not found");
        }

        if (!user.getPassword().equals(request.getPassword())) {
            throw new RuntimeException("Invalid password");
        }

        return "Login successful";
    }

    /* without using dto
    public User register(User user){
        User existing = userRepository.findByUsername(user.getUsername());
        if(existing!=null)
        {
            throw new RuntimeException("User already exists");
        }
        return userRepository.save(user);
    }

    public String login(String username, String password) {
    User user = userRepository.findByUsername(username);

    if (user == null) {
        return "User not found";
    }

    if (!user.getPassword().equals(password)) {
        return "Invalid password";
    }

    return "Login successful";
}
    */



}
