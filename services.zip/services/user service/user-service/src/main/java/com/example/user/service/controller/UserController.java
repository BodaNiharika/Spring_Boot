package com.example.user.service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.user.service.dto.UserRequest;
import com.example.user.service.dto.UserResponse;
import com.example.user.service.service.UserService;

import jakarta.validation.Valid;

// allows ui to talk to teh backend
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/auth")
public class UserController {

    @Autowired
    private UserService userService;


    @PostMapping("/register")
    public UserResponse register(@Valid @RequestBody UserRequest request){
        return userService.register(request);
    }

    @PostMapping("/login")
    public String login(@Valid @RequestBody UserRequest request){
        return userService.login(request);
    }

    /*without dto
    @PostMapping("/register")
    public User register(@RequestBody User user){
        return userService.register(user);
    }

    @PostMapping("/login")
    public String login(@RequestBody User user){
        return userService.login(user.getUsername(), user.getPassword());
    }
        */
}
