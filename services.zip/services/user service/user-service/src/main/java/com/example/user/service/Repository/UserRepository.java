package com.example.user.service.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.user.service.model.*;


public interface UserRepository extends JpaRepository<User, Long>{
    User findByUsername(String Username);
}
