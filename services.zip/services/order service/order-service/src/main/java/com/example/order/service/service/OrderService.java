package com.example.order.service.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.order.service.Repository.OrderRepository;
import com.example.order.service.model.Order;

@Service
public class OrderService {
    
    @Autowired
    OrderRepository orderRepository;
    
    // Java Object → SQL Query → Database Row
    public Order placeOrder(Order order){
        return orderRepository.save(order);
    }

    public List<Order> getAllOrders(){
        return orderRepository.findAll();
    }
}
