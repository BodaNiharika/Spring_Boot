package com.example.order.service.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.order.service.model.Order;

public interface OrderRepository extends JpaRepository<Order, Long>{

    
}